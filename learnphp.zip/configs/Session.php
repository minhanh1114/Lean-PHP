<?php
$config['session'] = [
    'session_key' => 'unicode_session'
];
?>