<?php
abstract class Middlewares{
    abstract function handle();
}