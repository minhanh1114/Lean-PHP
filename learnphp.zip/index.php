<?php
session_start();
require_once('./bootstrap.php');
$app = new App();



      
?>