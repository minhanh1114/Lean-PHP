<div style="background: #ccc; margin: 0 auto; width: 600px; padding: 20px;">
    <h1 style="text-align: center;">Đã xảy ra lỗi, vui lòng kiểm tra lại</h1>
    <hr/>
    <p><?php echo (!empty($message))?$message:false; ?></p>
</div>