<h1>Đã có lỗi liên quan truy vấn cơ sở dữ liệu</h1>
<?php 
echo (!empty($message)? $message : '');
?>