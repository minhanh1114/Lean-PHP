<?php
class News extends Controller{
    private $data =[];
    private $NewsModel;
    private $ProductModel;
        public function __construct()
        {
            $this->NewsModel = $this->model('NewsModel');
            $this->ProductModel = $this->model('ProductModel');
        }
    function index($slug){
    
    $this->data['sub_content']['dataNews'] = $this->NewsModel->getNewsSlug($slug);
    $this->data['sub_content']['dataNewsOffer'] = $this->NewsModel->getNewsList(5);
    $this->data['sub_content']['typesProduct'] = $this->ProductModel->getTypeProduct();
    $this->data['content']='news/index';
    $this->render('layouts/client_layout', $this->data);
    }
    function getAllNew(){
        echo 'tin tức ';
    }
   
}
//call_user_func_array([$this->__controller, $this->__action], $this->__params);
// câu lệnh thực hiện gọi function(action) với id(param) sang class(controller) chỉ định