<?php
class Home extends Controller{
    private $HomeModel;
    private $ProductModel;
    private $NewsModel;
    public $data=[];
    public function __construct(){
      $this->HomeModel = $this->model('HomeModel');
      $this->ProductModel = $this->model('ProductModel');
      $this->NewsModel = $this->model('NewsModel');
    }
    public function index (){
        $data['typesProduct']= $this->ProductModel->getTypeProduct();
        $dataNews = $this->NewsModel->getNewsList(3);
        for ($i=0; $i < count($dataNews); $i++) 
            {
                if(!empty($dataNews[$i]['description']))
                {
                    $dataNews[$i]['description'] = $this->character_limiter($dataNews[$i]['description'],100);
                    
                }
            }
            $data['news']=$dataNews;
        //get list products
        $data['productList']['one'] = $this->ProductModel->getProductList($data['typesProduct'][0]['id_type'],8);
        $data['productList']['two'] = $this->ProductModel->getProductList($data['typesProduct'][1]['id_type'],8);
        $data['productList']['three'] = $this->ProductModel->getProductList($data['typesProduct'][2]['id_type'],8);
        $data['productList']['four'] = $this->ProductModel->getProductList($data['typesProduct'][3]['id_type'],8);

        $this->render('home/index',$data);
    }
    public function contact()
    {
        $this->data['title'] = 'Liên hệ';
        $this->data['sub_content']['typesProduct'] = $this->ProductModel->getTypeProduct();
        $this->data['content'] = 'home/contact';
        $this->render('layouts/client_layout', $this->data);
    }
    public function introduce()
    {
        $this->data['title'] = 'Giới thiệu';
        $this->data['sub_content']['typesProduct'] = $this->ProductModel->getTypeProduct();
        $this->data['content'] = 'home/introduce';
        $this->render('layouts/client_layout', $this->data);
    }
    
    public function search (){
        $request = new Request();
        $response = new Response();
        $keyWord = $request->getDataRequest();
        if (!empty($keyWord["k"]))
        {
            // xử lí search
            $this->data['title'] = 'Tìm kiếm sản phẩm';
            $this->data['sub_content']['typesProduct'] = $this->ProductModel->getTypeProduct();
            $this->data['sub_content']['dataProduct'] = $this->ProductModel->searchProduct($keyWord["k"]);
            $this->data['sub_content']['keySearch'] = $keyWord["k"];
            $this->data['content'] = 'home/search';
            $this->render('layouts/client_layout', $this->data);
        }
        else
        {
            // redirect home page
            $response->redirect('');
        }
        
    }
    public function get_category(){
       $request = new Request();
        $data= $request->getDataRequest();
     $this->render('categorys/add');
       
    }
    public function post_category(){
       $request = new Request();
       $data=$request->getDataRequest();
    //    var_dump($data); truy vấn csdl
       $response = new Response();
       $response->redirect('home/get_category');
    //    $response->redirect('https://google.com/'); link ngoài web site

       

    }
}