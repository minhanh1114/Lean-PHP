<form method="post" action=" <?php echo _WEB_ROOT; ?>/home/post_category" >
    <input type="text" name = "id"/>
    <input type="text" name = "name_category"/>
    <input type="submit"/>
</form>