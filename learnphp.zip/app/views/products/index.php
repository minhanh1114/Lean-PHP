<h2>Danh sach san pham</h2>
<?php
var_dump($listProduct);